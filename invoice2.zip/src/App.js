 import React from 'react'
 import Invoice from './Components/Invoice'
 
 
 function App() {
   return (
     <div>
      
     <Invoice/>
    
     </div>
   )
 }
 
 export default App